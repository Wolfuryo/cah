<?php
//php files by controller and method
return [
'default'=>'main',
'main'=>'main,index',
'user'=>'main,user',
'user|login'=>'main,login'
];