<?php
//general configuration options
return [
'default_controller'=>'main',
];