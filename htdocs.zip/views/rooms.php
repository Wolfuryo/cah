{% extends "skeleton.php" %}
{% block main %}
{% if user.logged %}
{% else %}
{% endif %}
{% endblock %}