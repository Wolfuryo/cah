<?php
//database authentication
return [
'user'=>'root',
'pass'=>'',
'dbname'=>'devsland',
'host'=>'localhost',
'charset'=>'utf8mb4',
];