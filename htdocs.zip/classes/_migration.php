<?php
//simple migration class
//extended by all the other migrations
class _migration{

//run the migration
public function up(){}

//revert the migration
public function donw(){}

}