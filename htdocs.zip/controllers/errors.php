<?php
//the error controller
//used for displaying 404 errors
class errors extends Controller{

public function default(){
echo -1;
}

}