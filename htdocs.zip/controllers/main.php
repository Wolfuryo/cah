<?php
//the main controller, used for the index page
class main extends Controller{

public function default(){

$this->view('landing');

}

}