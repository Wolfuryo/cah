<?php
//load every php file in the folder classes
load_all('classes');
//load the composer autoload file
require_once(ROOT.'/vendor/autoload.php');